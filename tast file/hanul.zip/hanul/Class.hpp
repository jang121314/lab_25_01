﻿#pragma once



#include<string>
#include<vector>
#include<SDL.h>
#include<SDL_ttf.h>

#include<iostream>
#include<fstream>
#include<sstream>