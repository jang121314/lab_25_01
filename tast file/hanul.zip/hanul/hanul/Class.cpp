﻿#include "Class.hpp"

class Class
{

	class Sumer
	{
	public:
		template<typename T>
		static T max(T a, T b)
		{
			return a > b ? a : b;
		}
	};

	class Parser
	{

	public:

		int subString(std::vector<std::string>& output, std::string input, char low, char high)
		{
			output.push_back({});
			for (char get : input)
			{
				if (get == low)
				{
					output.push_back({});
					output.back().push_back(get);
				}
				else if (get == high)
				{
					output.back().push_back(get);
					output.push_back({});
				}
				else output.back().push_back(get);
			}

			return 0;
		}

		int twoString(std::string& low, std::string& high, std::string input, char point)
		{
			int flag = 0;
			for (char get : input)
			{
				if (get == point)
				{
					flag = 1;
				}
				else  switch (flag)
				{
				case 0:
					low.push_back(get);
					break;
				case 1:
					high.push_back(get);
					break;
				}
			}
			return 0;
		}

		int twoString(std::vector<std::string>& lowOutput, std::vector<std::string>& highOutPut, std::vector<std::string> input, char point)
		{

			for (std::string getString : input)
			{
				lowOutput.push_back({});
				highOutPut.push_back({});
				twoString(lowOutput.back(), highOutPut.back(), getString, point);
			}
			return 0;
		}

		int squish(std::string& string)
		{
			std::string output;
			for (char get : string)
			{
				if (get == ' ' || get == '\t' || get == '\n');
				else output.push_back(get);
			}
			string = output;
			return 0;
		}

		int squish(std::vector<std::string>& vector)
		{
			for (std::string& string : vector)
			{
				squish(string);
			}
			return 0;
		}

		int trim(std::string& string)
		{
			size_t index = 0;
			for (char get : string)
			{
				if (get == ' ' || get == '\t' || get == '\n') index++;
				else break;
			}
			if (string.size() <= index)
			{
				string = "";
				return -1;
			}
			std::string output = string.substr(index);
			for (char& get = output.back(); get == ' ' || get == '\t' || get == '\n'; output.pop_back());
			for (char& get = output.back(); get == ' ' || get == '\t' || get == '\n'; output.pop_back());
			string = output;
			return 0;
		}

		int tapToSpace(std::string& string)
		{
			std::string output;
			for (char get : string)
			{
				if (get == '\t')
				{
					output.append("     ");
				}
				else
				{
					output.push_back(get);
				}
			}
			string = output;
			return 0;
		}

		int split(std::vector<std::string>& output, std::string string, char point)
		{
			long long low = -1;
			size_t index = 0;
			for (char get : string)
			{
				if (get == point)
				{
					output.push_back( string.substr (low+1, index-low-1) );
					low = index;
				}
				index++;
			}
			if (index > low + 1)
			{
				output.push_back( string.substr(low + 1) );
			}
			return 0;
		}

		int to﻿Squish(std::string& string, char point)
		{
			std::string output;
			for (char get : string)
			{
				if(get != point) output.push_back(get);
			}
			string = output;
			return 0;
		}

	};

	template<typename T>
	class Property
	{
		T* val = nullptr;
		bool exist = false;

		int delVal()
		{
			if (val != nullptr)
			{
				delete val;
				val = nullptr;
			}
			exist = false;
			return 0;
		}

		int setVal(T get)
		{
			delVal();
			val = new T(get);
			exist = true;
			return 0;
		}

		int empty()
		{
			if (!val) return 1;
			return 0;
		}

	public:
		Property() : val(nullptr), exist(false) {}
		Property(T& get) : val(nullptr), exist(true)
		{
			setVal(get);
		}
		Property(Property& S)
		{
			if (S.exist)
			{
				setVal(*S.val);
				exist = S.exist;
			}
			else
			{
				delVal();
				exist = false;
			}
		}

		~Property()
		{
			delVal();
		}

		Property& operator=(T get)
		{
			setVal(get);
			return *this;
		}

		Property& operator|=(T get)
		{
			if (!exist) setVal(get);
		}

		Property& operator--(int)
		{
			delVal();
		}

		Property& operator--()
		{
			delVal();
		}

		T& operator*()
		{
			if (empty() == 1)
			{
				setVal({});
			}

			return *val;
		}

		T* operator->()
		{
			if (empty() == 1)
			{
				setVal({});
			}
			return val;
		}

		bool isExist()
		{
			return exist;
		}

	};

	class VirtualStyle
	{

#define named __name__

	protected:
	public:

		struct VtrualProperty
		{
			virtual std::string getNamed() = 0;

			virtual int isName(std::string string)
			{
				return string == getNamed() ? 1 : 0;
			}

			virtual int setDatafunction(std::string data) = 0;

			virtual int setChild(std::string name, std::string data)
			{
				return 0;
			}

			int setData(std::string string)
			{
				Parser parser;
				std::string name, data;
				parser.twoString(name, data, string, ':');
				parser.squish(name);
				parser.squish(data);
				return setData(name, data);
			}

			int setData(std::string name, std::string data)
			{
				if (setChild(name, data))
				{

				}
				else if (isName(name) == 1)
				{
					setDatafunction(data);
					return 1;
				}
				return -1;
			}
		};

		struct InChildVtrualProperty : public VtrualProperty
		{
			virtual int setDataChild(std::string name, std::string data) = 0;

			int setChild(std::string name, std::string data) override
			{
				Parser parser;
				std::string low, high;
				parser.twoString(low, high, name, '-');
				parser.squish(high);
				return setDataChild(high, data);
			}

		};


	private:

		struct IntegerProperty : public VtrualProperty
			{
				virtual std::string getNamed() override
				{
					return "IntegerProperty";
				}

				typedef long long int Type;
				Property<Type> IntegerData;

				virtual int setFunction(Type get)
				{
					IntegerData = get;
					return 0;
				}

				virtual int setDatafunction(std::string data) override
				{
					std::vector<int> vector;
					for (char get : data)
					{
						if ('0' <= get && get <= '9')
						{
							vector.push_back(int(get - '0'));
						}
					}
					long long int put = 0;
					size_t carry = 1;
					size_t vsize = 10 < vector.size() ? 10 : vector.size();
					for (int index = vsize - 1; index >= 0; index--)
					{
						char get = vector.at(index);
						put += get * carry;
						carry *= 10;
					}
					setFunction(put % 16384);
					return 0;
				}

				virtual Type& operator*()
				{
					return *IntegerData;
				}

				virtual Type* operator->()
				{
					return IntegerData.operator->();
				}
			};

	public:

		struct Color : public VtrualProperty
		{
			static constexpr const char* named = "color";

			std::string getNamed() override
			{
				return named;
			}

			unsigned char r, g, b, a;

			Color(unsigned char r = 0, unsigned char g = 0, unsigned char b = 0, unsigned char a = 255) : r(r), g(g), b(b), a(a)
			{

			}

			SDL_Color toSDL()
			{
				return SDL_Color{ .r = r, .g = g, .b = b, .a = a };
			}

			int setDatafunction(std::string data) override
			{
				if (data.empty())
				{
					return -1;
				}
				else if (data.at(0) == '#')
				{
					if (6 < data.size())
					{
						
						std::vector<int> val;
						for (int i = 0; i < 3; i++)
						{
							std::stringstream sstream;
							sstream << std::hex << data.substr(i*2+1, 2);
							val.push_back(0);
							sstream >> std::hex >> val.back();
						}
						r = val.at(0);
						g = val.at(1);
						b = val.at(2);
					}
					if (8 < data.size())
					{
						std::stringstream sstream;
						sstream << std::hex << data.substr(6);
						int val = 0;
						sstream >> val;
						a = val;
					}
					return 0;
				}
				if (data == "white")
				{
					r = 255;
					g = 255;
					b = 255;
					return 0;
				}
				if (data == "gray")
				{
					r = 128;
					g = 128;
					b = 128;
					return 0;
				}
				if (data == "black")
				{
					r = g = b = 0;
					return 0;
				}
				if (data == "red")
				{
					r = 255;
					return 0;
				}
				if (data == "yellow")
				{
					r = 255;
					g = 255;
					return 0;
				}
				if (data == "green")
				{
					g = 255;
					return 0;
				}
				if (data == "aqua ")
				{
					g = 255;
					b = 255;
					return 0;
				}
				if (data == "bule")
				{
					b = 255;
					return 0;
				}
				if (data == "magenta")
				{
					r = 255;
					b = 255;
					return 0;
				}
				return -2;
			}

		};

		struct Font : public InChildVtrualProperty
		{
			static constexpr const char* named = "font";
			std::string getNamed() override
			{
				return named;
			}

			struct Size : public IntegerProperty
			{
				std::string getNamed() override
				{
					return "size";
				}

			};

			Size size = {};

			int setDataChild(std::string name, std::string data) override
			{
				size.setData(name, data);
				return 1;
			}

			int setDatafunction(std::string data) override
			{
				return 0;
			}

			int apply(Font s)
			{
				size.IntegerData |= *s.size.IntegerData;
			}
		};

		struct Text : public InChildVtrualProperty
		{

			static constexpr const char* named = "text";
			std::string getNamed() override
			{
				return named;
			}

			struct Size : public IntegerProperty
			{
				std::string getNamed() override
				{
					return "size";
				}

			};

			Size size = {};

			int setDataChild(std::string name, std::string data) override
			{
				size.setData(name, data);
				return 1;
			}

			int setDatafunction(std::string data) override
			{
				return 0;
			}

			int apply(Text s)
			{
				size.IntegerData |= *s.size.IntegerData;
			}
		};

		struct Background : public InChildVtrualProperty
		{
			static constexpr const char* named = "background";
			std::string getNamed() override
			{
				return named;
			}

			Property<Color> color;

			int setDataChild(std::string name, std::string data) override
			{
				(*color).setData(name, data);
				return 1;
			}

			int setDatafunction(std::string data) override
			{
				return 0;
			}

			int apply(Background s)
			{
				color |= *s.color;
			}
		};

		struct Border : public InChildVtrualProperty
		{
			static constexpr const char* named = "border";
			std::string getNamed() override
			{
				return named;
			}

			struct Width : IntegerProperty
			{
				std::string getNamed() override
				{
					return "width";
				}
			};

			struct Style : VtrualProperty
			{
				std::string getNamed() override
				{
					return "style";
				}

				enum class Type
				{
					NONE,
					SOLID,
					DOUBLE,
				};

				Property<Type> type;

				int setDatafunction(std::string data) override
				{
					if (data == "none")
					{
						type = Type::NONE;
						return 0;
					}
					if (data == "solid")
					{
						type = Type::SOLID;
						return 0;
					}
					if (data == "double")
					{
						type = Type::DOUBLE;
						return 0;
					}
					return -1;
				}
			};

			Width width;
			Style style;
			Property<Color> color;

			int setDataChild(std::string name, std::string data) override
			{
				( width).setData(name, data);
				( style).setData(name, data);
				(*color).setData(name, data);
				return 1;
			}

			int setDatafunction(std::string data) override
			{
				return 0;
			}

			int apply(Border s)
			{
				width.IntegerData |= *s.width.IntegerData;
				style.type |= *style.type;
				color |= *s.color;
			}
		};

		struct Margin : public IntegerProperty
		{
			static constexpr const char* named = "margin";
			std::string getNamed() override
			{
				return named;
			}
		};

		struct Padding : public IntegerProperty
		{
			static constexpr const char* named = "padding";
			std::string getNamed() override
			{
				return named;
			}

		};

		struct Width : public IntegerProperty
		{
			static constexpr const char* named = "width";
			std::string getNamed() override
			{
				return named;
			}

		};

		struct Height : public IntegerProperty
		{
			static constexpr const char* named = "height";
			std::string getNamed() override
			{
				return named;
			}

		};

#undef named

	};

	class Style : public VirtualStyle
	{

	public:

		Property<Color> color = {};
		Font font = {};
		Text text = {};
		Background background = {};
		Border border = {};
		Margin margin = {};
		Padding padding = {};
		Width width = {};
		Height height = {};

		Style()
		{

		}

		Style(std::string string)
		{
			std::vector<std::string> vector;
			Parser parser;
			parser.split(vector, string, ';');
			for (std::string string : vector)
			{
				parser.squish(string);
				setting(string);
			}
		}

		int setting(std::string string)
		{
			(*color).setData(string);
			(font).setData(string);
			(text).setData(string);
			(background).setData(string);
			(border).setData(string);
			(margin).setData(string);
			(width).setData(string);
			(height).setData(string);
			return 0;
		}

		int apply(Style b)
		{
			auto& a = *this;
			a.color |= *b.color;
			a.font.apply(b.font);
			a.text.apply(b.text);
			a.background.apply(b.background);
			a.border.apply(b.border);
			a.margin.IntegerData |= *b.margin.IntegerData;
			a.padding.IntegerData |= *b.padding.IntegerData;
			a.width.IntegerData |= *b.width.IntegerData;
			a.height.IntegerData |= *b.height.IntegerData;
			return 0;
		}

	};

	class Tag
	{
	protected:

		struct Att
		{
			std::string name;
			std::string data;

			std::string toString()
			{
				return name + '=' + '"' + data + '"';
			}

		};

	public:

		std::string tag;
		std::vector<Att> att;

		Tag(std::string string)
		{
			int flag = 0;
			int Stringflag = 0;

			std::string name;
			std::string data;

			for (char get : string)
			{

				if (get == '<') continue;
				if (get == '>') break;

				switch (flag)
				{
				case 0:
					if (get == ' ' || get == '\t' || get == '\n')
					{

					}
					else
					{
						tag.push_back(get);
						flag = 1;
					}
					break;
				case 1:
					if (get == ' ' || get == '\t' || get == '\n')
					{
						flag = 2;
					}
					else
					{
						tag.push_back(get);
					}
					break;
				case 2:
					if (get == ' ' || get == '\t' || get == '\n')
					{

					}
					else
					{
						flag = 3;
						name.push_back(get);
					}
					break;
				case 3:
					if (get == ' ' || get == '\t' || get == '\n')
					{
						flag = 4;
					}
					else if (get == '=')
					{
						flag = 5;
					}
					else
					{
						name.push_back(get);
					}
					break;
				case 4:
					if (get == ' ' || get == '\t' || get == '\n')
					{

					}
					else if (get == '=')
					{
						flag = 5;
					}
					else
					{
						att.push_back({ name, {} });
						name.clear();
						flag = 3;
						name.push_back(get);
					}
					break;
				case 5:
					if (get == ' ' || get == '\t' || get == '\n')
					{

					}
					else if (get == '"')
					{
						flag = 6;
					}
					break;
				case 6:
					if (get == '"')
					{
						att.push_back({ name, data });
						name.clear();
						data.clear();
						flag = 2;
					}
					else
					{
						data.push_back(get);
					}
					break;
				}
			}


		}

		virtual std::string toString()
		{
			std::string output = tag;
			for (Att get : att)
			{
				output += ' ' + get.toString();
			}
			return output;
		}

	};

	class Element : public Tag
	{

	public:

		std::vector<Element*> content;

		Property<Style> style = {};

		Element(std::string string) : Tag(string)
		{
			for (Att get : att)
			{
				if (get.name == "style")
				{
					style = get.data;
;					break;
				}
			}
		}

		~Element()
		{
			for (Element* get : content)
			{
				delete get;
			}
		}

		virtual std::string stringContent()
		{
			return "";
		}

		virtual std::string toString() override
		{
			return '<' + Tag::toString() + '>';
		}

	};

	class textContent : public Element
	{
		std::string string;

	public:

		textContent(std::string string) : Element("<textContent>"), string(string)
		{
			
		}

		std::string stringContent() override
		{
			return string;
		}

	};

	class Document
	{

		Element content;
		

	public:

		Style* style = {};

		Document(std::string string) : content("<Document>")
		{
			std::vector<Element*> stack;
			stack.push_back(&content);

			Parser parser;
			std::vector<std::string> vector;
			parser.subString(vector, string, '<', '>');

			for (std::string get : vector)
			{
				//std::cout << "\npoint" << get;
			}

			for (std::string get : vector)
			{
				
				if (get.empty()) continue;

				std::string squishString = get;
				parser.squish(squishString);

				if (squishString.empty()) continue;

				if (squishString.at(0) == '<')
				{
					if(squishString.at(1) == '/')
					{
						stack.pop_back();
						if (stack.empty()) break;
					}
					else
					{
						Element* element = new Element(get);
						stack.back()->content.push_back(element);
						stack.push_back(element);
					}
				}
				else
				{
					if (parser.trim(get) == -1) continue;
					parser.to﻿Squish(get, '\n');
					parser.tapToSpace(get);
					Element* element = new textContent(get);
					stack.back()->content.push_back(element);
				}
			}

		}



		std::string getToString()
		{
			return getToStringFunction(&content);
		}

		Element& getElementContent()
		{
			return content;
		}

	private:

		std::string systemOutPrint(std::string string, size_t depth)
		{
			std::string output;
			for (int i = 0; i < depth; i++)
			{
				output += "    ";
			}
			if (!string.empty())
			{
				output += string;
				output += '\n';
			}
			return output;
		}

		std::string getToStringFunction(Element* element, size_t depth = 0)
		{
			std::string output;
			if ( element->tag == "textContent" )
			{
				output += systemOutPrint(element->stringContent(), depth);
			}
			else
			{
				output +=  systemOutPrint(element->toString(), depth);
				for (Element* get : element->content)
				{
					output += getToStringFunction(get, depth + 1);
				}
				output += systemOutPrint("</" + element->tag + '>', depth);
			}
			return output;
		}

	};

	class CSDL
	{
		SDL_Window* window = {};
		SDL_Renderer* renderer = {};
		TTF_Font* font = {};

		Style style = {};
		SDL_Color color = {};
		SDL_Point cursor = {};
		Document* document = {};
		
	public:

		CSDL(std::string name, int w, int h, size_t fontSize)
		{
			SDL_Init(SDL_INIT_VIDEO);
			TTF_Init();

			font = TTF_OpenFont(".\\lib\\NotoSansKR-VariableFont_wght.ttf", fontSize);
			if (!font) std::cout << "이런";

			window = SDL_CreateWindow(name.c_str(), SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, w, h, SDL_WINDOW_SHOWN);
			renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_TARGETTEXTURE);

			color = { 0, 0, 0, 255 };

		}

		~CSDL()
		{
			if (renderer) SDL_DestroyRenderer(renderer);
			if (window) SDL_DestroyWindow(window);
			if (font) TTF_CloseFont(font);

		}

		int EventLoop()
		{
			SDL_Event event = {};
			while (SDL_PollEvent(&event))
			{
				switch (event.type)
				{
				case SDL_QUIT:
					return 0;
					break;
				}
			}
			return 1;
		}

		int DrawLoop()
		{
			SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
			SDL_RenderClear(renderer);
			SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
			cursor = {};
			{
				if(document) SimpleDrawElement(&document->getElementContent());
			}
			SDL_RenderPresent(renderer);
			return 0;
		}

		int DrawString(std::string string)
		{

			SDL_Surface* surface = TTF_RenderUTF8_Blended(font, string.c_str(), color);
			if (!surface) return -1;

			SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
			SDL_FreeSurface(surface);

			if(!texture) return -1;

			SDL_Rect rect = {};
			SDL_QueryTexture(texture, NULL, NULL, &rect.w, &rect.h);
			rect.x = cursor.x;
			rect.y = cursor.y;

			SDL_RenderCopy(renderer, texture, NULL, &rect);

			cursor.y += rect.h;
			SDL_DestroyTexture(texture);
			return 0;
		}

		int setDocument(Document& document)
		{
			this->document = &document;
			return 0;
		}

	private:

		int ElementSettingFunction(Element* element, int& w, int& h)
		{
			Sumer sumer;
			int width = 0;
			int height = 0;
			if (element->tag == "textContent")
			{
				TTF_SizeUTF8(font, element->stringContent().c_str(), &width, &height);
			}
			else for (Element* element : element->content)
			{
				int getWidth = 0;
				int getHeight = 0;
				ElementSettingFunction(element, getWidth, getHeight);
				width = sumer.max(width, getHeight);
				height += getHeight;
			}
			*element->style->width |= width;
			*element->style->width |= height;
			w = width;
			h = height;
			return 0;
		}

		int ElementSetting(Element* element)
		{
			int w = 0, h = 0;
			ElementSettingFunction(element, w, h);
			return 0;
		}

		int DrawElement(Element* element)
		{
			if (element->tag == "textContent")
			{
				DrawString(element->stringContent());
			}
			else
			{
				for (Element* element : element->content)
				{

				}
			}
			return 0;
		}

		int SimpleDrawElement(Element* element)
		{
			if (element->tag == "textContent")
			{
				DrawString(element->stringContent());
			}
			else
			{
				for (Element* get : element->content)
				{
					SimpleDrawElement(get);
				}
			}
			return 0;
		}

		int ElementStyleDraw(Element* element, Style base)
		{
			if (!element->style.isExist()) return -2;
			Style elementStyle = *element->style;
			elementStyle.apply(base);
			Style& s = elementStyle;
			if (s.background.color.isExist())
			{
				SDL_Rect rect = { .x = cursor.x, .y = cursor.y, .w = *s.width, .h = *s.height };
				SDL_RenderFillRect(renderer, &rect);
			}
			if (*s.border.style.type != VirtualStyle::Border::Style::Type::SOLID)
			{
				switch (*s.border.style.type)
				{
				case VirtualStyle::Border::Style::Type::SOLID:
				{

				}
					break;
				}
			}
		}

	};

	class Tester
	{
		class stream
		{
			std::stringstream sstream;
		public:

			template<class T>
			stream& operator<<(T get)
			{
				sstream << get << '\n';
				return *this;
			}

			stream& clear()
			{
				sstream.clear();
				return *this;
			}

			stream& print()
			{
				std::cout << sstream.str();
				return *this;
			}

			std::string str()
			{
				return sstream.str();
			}

			
		} cs;

	protected:
		int testColor()
		{
			std::stringstream sstream;
			VirtualStyle::Color color;
			sstream << color.setData("color: #FF00FFFF") << "\n";
			sstream << (int)color.r << "\n";
			sstream << (int)color.g << "\n";
			sstream << (int)color.b << "\n";
			sstream << (int)color.a << "\n";
			messag += sstream.str();
			return 0;
		}
		int testProperty()
		{
			using prop = Property<int>;
			prop p;

			cs << *p;
			p = 13;
			cs << *p;
			p = 24;
			cs << *p;

			messag += cs.str();
			return 0;
		}
		int testFont()
		{
			VirtualStyle::Font font;
			font.setData("font-size: 236");
			cs << *font.size.IntegerData;
			cs.print();
			return 0;
		}
		int testPropertyColor()
		{
			Property<VirtualStyle::Color> color;
			color->setData("color: #FF00FF");
			cs << (int)color->r;
			cs << (int)color->g;
			cs << (int)color->b;
			cs << (int)color->a;
			cs.print();
			return 0;
		}
		int testBackground()
		{
			VirtualStyle::Background s;
			s.setData("background-color: #FF00FF00");
			auto& color = s.color;
			cs << (int)color->r;
			cs << (int)color->g;
			cs << (int)color->b;
			cs << (int)color->a;
			cs.print();
			return 0;
		}
		int testBorder()
		{
			VirtualStyle::Border b;
			b.setData("border-color: #FF00FF");
			b.setData("border-width: 20");
			b.setData("border-style: solid");
			auto& color = b.color;
			cs << 'r' << (int)color->r;
			cs << 'g' << (int)color->g;
			cs << 'b' << (int)color->b;
			cs << 'a' << (int)color->a;
			cs << *b.width;
			cs << (*b.style.type == VirtualStyle::Border::Style::Type::SOLID ? "solid" : "none");
			cs.print();
			return 0;
		}
		int testStyle()
		{
			Property<Style> style;
			style = std::string("color: #0000FF; width: 20; color: red;");
			Property<VirtualStyle::Color> color;
			color = *style->color;
			cs << 'r' << (int)color->r;
			cs << 'g' << (int)color->g;
			cs << 'b' << (int)color->b;
			cs << 'a' << (int)color->a;
			cs << *style->width;
			cs.print();
			return 0;
		}
	public:
		int error = 0;
		std::string messag;
		Tester()
		{
			error = testStyle();
			std::cout << messag;
		}
	};


public:


	int main(int argc, char** argv)
	{
		Tester t;

		std::string string;
		if (1 < argc)
		{
			std::ifstream istream(argv[1]);
			std::stringstream sstream;
			sstream << istream.rdbuf();
			string = sstream.str();
			//std::cout << string;
			if (string.size() >= 3 &&
				(unsigned char)string[0] == 0xEF &&
				(unsigned char)string[1] == 0xBB &&
				(unsigned char)string[2] == 0xBF) {
				string.erase(0, 3);
			}
		}

		Document document(string);
		std::cout << document.getToString();
		CSDL SDL("윈도우 입니다", 600, 400, 20);
		SDL.setDocument(document);
		while ( SDL.EventLoop() )
		{
			SDL.DrawLoop();
		}
		return 0;
	}


};

#include <Windows.h>

int main(int argc, char** argv)
{
	SetConsoleOutputCP(65001);
	return Class().main(argc, argv);
}
